function pessoas(){
   var idade, peso, altura;
   var qtdeIdade = 0; var qtdePeso = 0; var qtdeAltura = 0; var percentual, media;
   var somaAltura = 0;
    // entrade de dados 
    for(i=0;i<3;i++){
        idade = parseInt(prompt("Informe idade da pessoa"));
        altura = parseFloat(prompt("Informe altura da pessoa"));
        peso = parseFloat(prompt("Informe peso da pessoa"));
        
        if (idade > 50){
            qtdeIdade++;
        }
        if ((idade > 10) && (idade < 20)){
            qtdeAltura++;
            somaAltura += altura; // somaAltura = somaAltura + altura 
        }
        if (peso < 40){
            qtdePeso++;
        }
    }
    // média de altura das pessoas com idade entre 10 e 20
    if (qtdeAltura == 0){
        media = 0;
    }
    else media = somaAltura / qtdeAltura;
    // percentual de pessoas com peso < 40
    percentual = (qtdePeso / 3) * 100;
    
    // saída
    document.getElementById("qtdeIdade").innerHTML = qtdeIdade.toFixed(2);
    document.getElementById("media").innerHTML = media.toFixed(2);
    document.getElementById("percentual").innerHTML = percentual.toFixed(2);
}